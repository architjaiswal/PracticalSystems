var searchData=
[
  ['global_2ecpp',['global.cpp',['../global_8cpp.html',1,'']]],
  ['global_2eh',['global.h',['../global_8h.html',1,'']]],
  ['gui_5fapp',['gui_app',['../global_8cpp.html#afe8961a6c8e9609c342b33cf8012c320',1,'gui_app():&#160;global.cpp'],['../global_8h.html#afe8961a6c8e9609c342b33cf8012c320',1,'gui_app():&#160;global.cpp']]],
  ['gui_5fwindow_5fappwidgets',['Gui_Window_AppWidgets',['../structGui__Window__AppWidgets.html',1,'']]],
  ['guiappget',['GuiappGET',['../main_8cpp.html#a7ffcc27689dcff0f1f551da88cfd56bd',1,'main.cpp']]]
];
