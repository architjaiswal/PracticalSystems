var searchData=
[
  ['window1',['window1',['../structGui__Window__AppWidgets.html#a75655c4f085a0ece07953acd075b7637',1,'Gui_Window_AppWidgets']]]
];
