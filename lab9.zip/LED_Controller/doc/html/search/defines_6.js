var searchData=
[
  ['voltage_5fdisplay_5fupdate_5fms',['VOLTAGE_DISPLAY_UPDATE_MS',['../main_8cpp.html#a736aeda0653ee56f9d9a4fd12b45166e',1,'main.cpp']]]
];
