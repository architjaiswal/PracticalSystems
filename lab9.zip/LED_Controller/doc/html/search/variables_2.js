var searchData=
[
  ['gui_5fapp',['gui_app',['../global_8cpp.html#afe8961a6c8e9609c342b33cf8012c320',1,'gui_app():&#160;global.cpp'],['../global_8h.html#afe8961a6c8e9609c342b33cf8012c320',1,'gui_app():&#160;global.cpp']]]
];
