var searchData=
[
  ['entry_5fsd',['entry_sd',['../structGui__Window__AppWidgets.html#a996d081f89c3558e5469ec5ea241354c',1,'Gui_Window_AppWidgets']]]
];
