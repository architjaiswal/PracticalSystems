var indexSectionsWithContent =
{
  0: "_bcegklmoprstvw",
  1: "g",
  2: "gmsw",
  3: "bmosv",
  4: "cegklmsw",
  5: "_bgmprv",
  6: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

